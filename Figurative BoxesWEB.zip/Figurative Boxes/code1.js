gdjs.HowtoCode = {};
gdjs.HowtoCode.GDTitleObjects1= [];
gdjs.HowtoCode.GDTitleObjects2= [];
gdjs.HowtoCode.GDTitle2Objects1= [];
gdjs.HowtoCode.GDTitle2Objects2= [];
gdjs.HowtoCode.GDFloorObjects1= [];
gdjs.HowtoCode.GDFloorObjects2= [];
gdjs.HowtoCode.GDPlayObjects1= [];
gdjs.HowtoCode.GDPlayObjects2= [];
gdjs.HowtoCode.GDBacktoObjects1= [];
gdjs.HowtoCode.GDBacktoObjects2= [];
gdjs.HowtoCode.GDHowToPlayObjects1= [];
gdjs.HowtoCode.GDHowToPlayObjects2= [];
gdjs.HowtoCode.GDHowToTxtObjects1= [];
gdjs.HowtoCode.GDHowToTxtObjects2= [];
gdjs.HowtoCode.GDPunchableObjects1= [];
gdjs.HowtoCode.GDPunchableObjects2= [];
gdjs.HowtoCode.GDDebugTool2Objects1= [];
gdjs.HowtoCode.GDDebugTool2Objects2= [];
gdjs.HowtoCode.GDDebugToolObjects1= [];
gdjs.HowtoCode.GDDebugToolObjects2= [];
gdjs.HowtoCode.GDboXTextObjects1= [];
gdjs.HowtoCode.GDboXTextObjects2= [];
gdjs.HowtoCode.GDGamemodeTxtObjects1= [];
gdjs.HowtoCode.GDGamemodeTxtObjects2= [];
gdjs.HowtoCode.GDClickObjects1= [];
gdjs.HowtoCode.GDClickObjects2= [];
gdjs.HowtoCode.GDPlayTxtObjects1= [];
gdjs.HowtoCode.GDPlayTxtObjects2= [];
gdjs.HowtoCode.GDCursorObjects1= [];
gdjs.HowtoCode.GDCursorObjects2= [];
gdjs.HowtoCode.GDNewTiledSpriteObjects1= [];
gdjs.HowtoCode.GDNewTiledSpriteObjects2= [];
gdjs.HowtoCode.GDBackObjects1= [];
gdjs.HowtoCode.GDBackObjects2= [];
gdjs.HowtoCode.GDForwardObjects1= [];
gdjs.HowtoCode.GDForwardObjects2= [];
gdjs.HowtoCode.GDNewTiledSprite2Objects1= [];
gdjs.HowtoCode.GDNewTiledSprite2Objects2= [];
gdjs.HowtoCode.GDNewTextObjects1= [];
gdjs.HowtoCode.GDNewTextObjects2= [];
gdjs.HowtoCode.GDBoxObjects1= [];
gdjs.HowtoCode.GDBoxObjects2= [];
gdjs.HowtoCode.GDBallSpawnerObjects1= [];
gdjs.HowtoCode.GDBallSpawnerObjects2= [];
gdjs.HowtoCode.GDBallObjects1= [];
gdjs.HowtoCode.GDBallObjects2= [];
gdjs.HowtoCode.GDSelectObjects1= [];
gdjs.HowtoCode.GDSelectObjects2= [];
gdjs.HowtoCode.GDSignObjects1= [];
gdjs.HowtoCode.GDSignObjects2= [];

gdjs.HowtoCode.conditionTrue_0 = {val:false};
gdjs.HowtoCode.condition0IsTrue_0 = {val:false};
gdjs.HowtoCode.condition1IsTrue_0 = {val:false};
gdjs.HowtoCode.condition2IsTrue_0 = {val:false};
gdjs.HowtoCode.condition3IsTrue_0 = {val:false};
gdjs.HowtoCode.condition4IsTrue_0 = {val:false};
gdjs.HowtoCode.conditionTrue_1 = {val:false};
gdjs.HowtoCode.condition0IsTrue_1 = {val:false};
gdjs.HowtoCode.condition1IsTrue_1 = {val:false};
gdjs.HowtoCode.condition2IsTrue_1 = {val:false};
gdjs.HowtoCode.condition3IsTrue_1 = {val:false};
gdjs.HowtoCode.condition4IsTrue_1 = {val:false};


gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.HowtoCode.GDCursorObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.HowtoCode.GDPlayObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.HowtoCode.GDCursorObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.HowtoCode.GDBackObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.HowtoCode.GDCursorObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDForwardObjects1Objects = Hashtable.newFrom({"Forward": gdjs.HowtoCode.GDForwardObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.HowtoCode.GDCursorObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBacktoObjects1Objects = Hashtable.newFrom({"Backto": gdjs.HowtoCode.GDBacktoObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.HowtoCode.GDCursorObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects = Hashtable.newFrom({"Box": gdjs.HowtoCode.GDBoxObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.HowtoCode.GDBallObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.HowtoCode.GDBallObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects = Hashtable.newFrom({"Box": gdjs.HowtoCode.GDBoxObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.HowtoCode.GDCursorObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects = Hashtable.newFrom({"Box": gdjs.HowtoCode.GDBoxObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.HowtoCode.GDCursorObjects1});
gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects = Hashtable.newFrom({"Box": gdjs.HowtoCode.GDBoxObjects1});
gdjs.HowtoCode.eventsList0 = function(runtimeScene) {

{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 0;
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(3);
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 4;
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(1);
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDCursorObjects1[i].setColor("0;0;0");
}
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDCursorObjects1[i].setColor("255;255;255");
}
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HowToTxt"), gdjs.HowtoCode.GDHowToTxtObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.HowtoCode.GDNewTiledSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayTxt"), gdjs.HowtoCode.GDPlayTxtObjects1);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.HowtoCode.GDTitleObjects1);
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "647753fc018c01d628d50774d5f831c492daf6da5e6594843256062425d1e3dc_Bass Meant Jazz.aac", 1, true, 80, 1);
}{for(var i = 0, len = gdjs.HowtoCode.GDTitleObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDTitleObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(10, 5, 5, 0, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.HowtoCode.GDNewTiledSpriteObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDNewTiledSpriteObjects1[i].setColor("80;77;77");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.HowtoCode.GDPlayTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDPlayTxtObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(10, 5, 5, 0, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.HowtoCode.GDHowToTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDHowToTxtObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(10, 5, 5, 0, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.HowtoCode.GDNewTiledSpriteObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDNewTiledSpriteObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDNewTiledSpriteObjects1[i].addPolarForce(195, 150, 0);
}
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
gdjs.HowtoCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Click"), gdjs.HowtoCode.GDClickObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowToPlay"), gdjs.HowtoCode.GDHowToPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowToTxt"), gdjs.HowtoCode.GDHowToTxtObjects1);
gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.HowtoCode.GDPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayTxt"), gdjs.HowtoCode.GDPlayTxtObjects1);
gdjs.copyArray(runtimeScene.getObjects("Punchable"), gdjs.HowtoCode.GDPunchableObjects1);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.HowtoCode.GDTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Title2"), gdjs.HowtoCode.GDTitle2Objects1);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.HowtoCode.GDClickObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDClickObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.HowtoCode.GDTitleObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDTitleObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 104, "easeFrom", 1000, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDTitle2Objects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDTitle2Objects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 114, "easeFrom", 1000, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDPlayObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 512, "easeFrom", 1500, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDPlayTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDPlayTxtObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 613, "easeFrom", 1500, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDHowToPlayObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDHowToPlayObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 512, "easeFrom", 1800, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDHowToTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDHowToTxtObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 578, "easeFrom", 1800, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDPunchableObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDPunchableObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 957, "swingFrom", 1000, false);
}
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
gdjs.HowtoCode.condition2IsTrue_0.val = false;
gdjs.HowtoCode.condition3IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
gdjs.HowtoCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "k");
}if ( gdjs.HowtoCode.condition1IsTrue_0.val ) {
{
gdjs.HowtoCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}if ( gdjs.HowtoCode.condition2IsTrue_0.val ) {
{
{gdjs.HowtoCode.conditionTrue_1 = gdjs.HowtoCode.condition3IsTrue_0;
gdjs.HowtoCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8235932);
}
}}
}
}
if (gdjs.HowtoCode.condition3IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Tick.wav", false, 100, 1);
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DebugTool"), gdjs.HowtoCode.GDDebugToolObjects1);
gdjs.copyArray(runtimeScene.getObjects("DebugTool2"), gdjs.HowtoCode.GDDebugTool2Objects1);
{for(var i = 0, len = gdjs.HowtoCode.GDDebugToolObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDDebugToolObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.HowtoCode.GDDebugTool2Objects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDDebugTool2Objects1[i].hide();
}
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DebugTool"), gdjs.HowtoCode.GDDebugToolObjects1);
gdjs.copyArray(runtimeScene.getObjects("DebugTool2"), gdjs.HowtoCode.GDDebugTool2Objects1);
{for(var i = 0, len = gdjs.HowtoCode.GDDebugToolObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDDebugToolObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDDebugTool2Objects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDDebugTool2Objects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.HowtoCode.GDPlayObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
gdjs.HowtoCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDPlayObjects1Objects, false, runtimeScene, false);
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.HowtoCode.GDBackObjects1);
gdjs.copyArray(runtimeScene.getObjects("Backto"), gdjs.HowtoCode.GDBacktoObjects1);
gdjs.copyArray(runtimeScene.getObjects("Forward"), gdjs.HowtoCode.GDForwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("GamemodeTxt"), gdjs.HowtoCode.GDGamemodeTxtObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowToPlay"), gdjs.HowtoCode.GDHowToPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("HowToTxt"), gdjs.HowtoCode.GDHowToTxtObjects1);
/* Reuse gdjs.HowtoCode.GDPlayObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PlayTxt"), gdjs.HowtoCode.GDPlayTxtObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "confirmation_003.ogg", false, 100, 1);
}{for(var i = 0, len = gdjs.HowtoCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDPlayObjects1[i].getBehavior("Tween").addObjectPositionXTween("Clicked", -(1024), "easeFrom", 1000, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDPlayTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDPlayTxtObjects1[i].getBehavior("Tween").addObjectPositionXTween("Clicked", -(1024), "easeFrom", 1000, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDHowToPlayObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDHowToPlayObjects1[i].getBehavior("Tween").addObjectPositionXTween("Clicked", 1664, "easeFrom", 1000, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDHowToTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDHowToTxtObjects1[i].getBehavior("Tween").addObjectPositionXTween("Clicked", 1664, "easeFrom", 1000, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDBackObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 511, "easeFrom", 1500, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDForwardObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDForwardObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 511, "easeFrom", 1500, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDBacktoObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDBacktoObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 511, "easeFrom", 1500, false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDGamemodeTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDGamemodeTxtObjects1[i].getBehavior("Tween").addObjectPositionYTween("Clicked", 550, "easeFrom", 1500, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.HowtoCode.GDBackObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
gdjs.HowtoCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBackObjects1Objects, false, runtimeScene, false);
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Forward"), gdjs.HowtoCode.GDForwardObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
gdjs.HowtoCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDForwardObjects1Objects, false, runtimeScene, false);
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(14).add(1);
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 1;
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GamemodeTxt"), gdjs.HowtoCode.GDGamemodeTxtObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDGamemodeTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDGamemodeTxtObjects1[i].setString("60 SECONDS");
}
}{for(var i = 0, len = gdjs.HowtoCode.GDGamemodeTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDGamemodeTxtObjects1[i].setColor("0;0;0");
}
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 2;
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GamemodeTxt"), gdjs.HowtoCode.GDGamemodeTxtObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDGamemodeTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDGamemodeTxtObjects1[i].setString("PANIC MODE");
}
}{for(var i = 0, len = gdjs.HowtoCode.GDGamemodeTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDGamemodeTxtObjects1[i].setColor("255;0;0");
}
}}

}


{


gdjs.HowtoCode.condition0IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 3;
}if (gdjs.HowtoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GamemodeTxt"), gdjs.HowtoCode.GDGamemodeTxtObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDGamemodeTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDGamemodeTxtObjects1[i].setString("ENDLESS MODE");
}
}{for(var i = 0, len = gdjs.HowtoCode.GDGamemodeTxtObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDGamemodeTxtObjects1[i].setColor("0;68;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backto"), gdjs.HowtoCode.GDBacktoObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
gdjs.HowtoCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBacktoObjects1Objects, false, runtimeScene, false);
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Game");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.HowtoCode.GDBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
gdjs.HowtoCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects, false, runtimeScene, false);
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BallSpawner"), gdjs.HowtoCode.GDBallSpawnerObjects1);
gdjs.HowtoCode.GDBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBallObjects1Objects, (( gdjs.HowtoCode.GDBallSpawnerObjects1.length === 0 ) ? 0 :gdjs.HowtoCode.GDBallSpawnerObjects1[0].getPointX("Origin")), (( gdjs.HowtoCode.GDBallSpawnerObjects1.length === 0 ) ? 0 :gdjs.HowtoCode.GDBallSpawnerObjects1[0].getPointY("Origin")), "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.HowtoCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.HowtoCode.GDBoxObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBallObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects, false, runtimeScene, false);
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
{gdjs.HowtoCode.conditionTrue_1 = gdjs.HowtoCode.condition1IsTrue_0;
gdjs.HowtoCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11956084);
}
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
/* Reuse gdjs.HowtoCode.GDBallObjects1 */
{for(var i = 0, len = gdjs.HowtoCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDBallObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "confirmation_002.ogg", false, 100, 1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.5, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.HowtoCode.GDBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects, false, runtimeScene, false);
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
{gdjs.HowtoCode.conditionTrue_1 = gdjs.HowtoCode.condition1IsTrue_0;
gdjs.HowtoCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9557076);
}
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Select"), gdjs.HowtoCode.GDSelectObjects1);
gdjs.copyArray(runtimeScene.getObjects("boXText"), gdjs.HowtoCode.GDboXTextObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDSelectObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDSelectObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.HowtoCode.GDboXTextObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDboXTextObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "drop_003.ogg", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.HowtoCode.GDBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.HowtoCode.GDCursorObjects1);

gdjs.HowtoCode.condition0IsTrue_0.val = false;
gdjs.HowtoCode.condition1IsTrue_0.val = false;
{
gdjs.HowtoCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDCursorObjects1Objects, gdjs.HowtoCode.mapOfGDgdjs_46HowtoCode_46GDBoxObjects1Objects, true, runtimeScene, false);
}if ( gdjs.HowtoCode.condition0IsTrue_0.val ) {
{
{gdjs.HowtoCode.conditionTrue_1 = gdjs.HowtoCode.condition1IsTrue_0;
gdjs.HowtoCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11955924);
}
}}
if (gdjs.HowtoCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Select"), gdjs.HowtoCode.GDSelectObjects1);
gdjs.copyArray(runtimeScene.getObjects("boXText"), gdjs.HowtoCode.GDboXTextObjects1);
{for(var i = 0, len = gdjs.HowtoCode.GDSelectObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDSelectObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.HowtoCode.GDboXTextObjects1.length ;i < len;++i) {
    gdjs.HowtoCode.GDboXTextObjects1[i].hide();
}
}}

}


};

gdjs.HowtoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.HowtoCode.GDTitleObjects1.length = 0;
gdjs.HowtoCode.GDTitleObjects2.length = 0;
gdjs.HowtoCode.GDTitle2Objects1.length = 0;
gdjs.HowtoCode.GDTitle2Objects2.length = 0;
gdjs.HowtoCode.GDFloorObjects1.length = 0;
gdjs.HowtoCode.GDFloorObjects2.length = 0;
gdjs.HowtoCode.GDPlayObjects1.length = 0;
gdjs.HowtoCode.GDPlayObjects2.length = 0;
gdjs.HowtoCode.GDBacktoObjects1.length = 0;
gdjs.HowtoCode.GDBacktoObjects2.length = 0;
gdjs.HowtoCode.GDHowToPlayObjects1.length = 0;
gdjs.HowtoCode.GDHowToPlayObjects2.length = 0;
gdjs.HowtoCode.GDHowToTxtObjects1.length = 0;
gdjs.HowtoCode.GDHowToTxtObjects2.length = 0;
gdjs.HowtoCode.GDPunchableObjects1.length = 0;
gdjs.HowtoCode.GDPunchableObjects2.length = 0;
gdjs.HowtoCode.GDDebugTool2Objects1.length = 0;
gdjs.HowtoCode.GDDebugTool2Objects2.length = 0;
gdjs.HowtoCode.GDDebugToolObjects1.length = 0;
gdjs.HowtoCode.GDDebugToolObjects2.length = 0;
gdjs.HowtoCode.GDboXTextObjects1.length = 0;
gdjs.HowtoCode.GDboXTextObjects2.length = 0;
gdjs.HowtoCode.GDGamemodeTxtObjects1.length = 0;
gdjs.HowtoCode.GDGamemodeTxtObjects2.length = 0;
gdjs.HowtoCode.GDClickObjects1.length = 0;
gdjs.HowtoCode.GDClickObjects2.length = 0;
gdjs.HowtoCode.GDPlayTxtObjects1.length = 0;
gdjs.HowtoCode.GDPlayTxtObjects2.length = 0;
gdjs.HowtoCode.GDCursorObjects1.length = 0;
gdjs.HowtoCode.GDCursorObjects2.length = 0;
gdjs.HowtoCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.HowtoCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.HowtoCode.GDBackObjects1.length = 0;
gdjs.HowtoCode.GDBackObjects2.length = 0;
gdjs.HowtoCode.GDForwardObjects1.length = 0;
gdjs.HowtoCode.GDForwardObjects2.length = 0;
gdjs.HowtoCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.HowtoCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.HowtoCode.GDNewTextObjects1.length = 0;
gdjs.HowtoCode.GDNewTextObjects2.length = 0;
gdjs.HowtoCode.GDBoxObjects1.length = 0;
gdjs.HowtoCode.GDBoxObjects2.length = 0;
gdjs.HowtoCode.GDBallSpawnerObjects1.length = 0;
gdjs.HowtoCode.GDBallSpawnerObjects2.length = 0;
gdjs.HowtoCode.GDBallObjects1.length = 0;
gdjs.HowtoCode.GDBallObjects2.length = 0;
gdjs.HowtoCode.GDSelectObjects1.length = 0;
gdjs.HowtoCode.GDSelectObjects2.length = 0;
gdjs.HowtoCode.GDSignObjects1.length = 0;
gdjs.HowtoCode.GDSignObjects2.length = 0;

gdjs.HowtoCode.eventsList0(runtimeScene);

return;

}

gdjs['HowtoCode'] = gdjs.HowtoCode;
