gdjs.GameCode = {};
gdjs.GameCode.GDCursorObjects1= [];
gdjs.GameCode.GDCursorObjects2= [];
gdjs.GameCode.GDCursorObjects3= [];
gdjs.GameCode.GDCursorObjects4= [];
gdjs.GameCode.GDNewTiledSpriteObjects1= [];
gdjs.GameCode.GDNewTiledSpriteObjects2= [];
gdjs.GameCode.GDNewTiledSpriteObjects3= [];
gdjs.GameCode.GDNewTiledSpriteObjects4= [];
gdjs.GameCode.GDNewTiledSprite2Objects1= [];
gdjs.GameCode.GDNewTiledSprite2Objects2= [];
gdjs.GameCode.GDNewTiledSprite2Objects3= [];
gdjs.GameCode.GDNewTiledSprite2Objects4= [];
gdjs.GameCode.GDSimileObjects1= [];
gdjs.GameCode.GDSimileObjects2= [];
gdjs.GameCode.GDSimileObjects3= [];
gdjs.GameCode.GDSimileObjects4= [];
gdjs.GameCode.GDHyperboleObjects1= [];
gdjs.GameCode.GDHyperboleObjects2= [];
gdjs.GameCode.GDHyperboleObjects3= [];
gdjs.GameCode.GDHyperboleObjects4= [];
gdjs.GameCode.GDMetaphorObjects1= [];
gdjs.GameCode.GDMetaphorObjects2= [];
gdjs.GameCode.GDMetaphorObjects3= [];
gdjs.GameCode.GDMetaphorObjects4= [];
gdjs.GameCode.GDPersonificationObjects1= [];
gdjs.GameCode.GDPersonificationObjects2= [];
gdjs.GameCode.GDPersonificationObjects3= [];
gdjs.GameCode.GDPersonificationObjects4= [];
gdjs.GameCode.GDSelectSimileObjects1= [];
gdjs.GameCode.GDSelectSimileObjects2= [];
gdjs.GameCode.GDSelectSimileObjects3= [];
gdjs.GameCode.GDSelectSimileObjects4= [];
gdjs.GameCode.GDSelectHyperboleObjects1= [];
gdjs.GameCode.GDSelectHyperboleObjects2= [];
gdjs.GameCode.GDSelectHyperboleObjects3= [];
gdjs.GameCode.GDSelectHyperboleObjects4= [];
gdjs.GameCode.GDSelectMetaphorObjects1= [];
gdjs.GameCode.GDSelectMetaphorObjects2= [];
gdjs.GameCode.GDSelectMetaphorObjects3= [];
gdjs.GameCode.GDSelectMetaphorObjects4= [];
gdjs.GameCode.GDSelectPersonificationObjects1= [];
gdjs.GameCode.GDSelectPersonificationObjects2= [];
gdjs.GameCode.GDSelectPersonificationObjects3= [];
gdjs.GameCode.GDSelectPersonificationObjects4= [];
gdjs.GameCode.GDDropSimileObjects1= [];
gdjs.GameCode.GDDropSimileObjects2= [];
gdjs.GameCode.GDDropSimileObjects3= [];
gdjs.GameCode.GDDropSimileObjects4= [];
gdjs.GameCode.GDDropHyperboleObjects1= [];
gdjs.GameCode.GDDropHyperboleObjects2= [];
gdjs.GameCode.GDDropHyperboleObjects3= [];
gdjs.GameCode.GDDropHyperboleObjects4= [];
gdjs.GameCode.GDDropMetaphorObjects1= [];
gdjs.GameCode.GDDropMetaphorObjects2= [];
gdjs.GameCode.GDDropMetaphorObjects3= [];
gdjs.GameCode.GDDropMetaphorObjects4= [];
gdjs.GameCode.GDDropPersonificationObjects1= [];
gdjs.GameCode.GDDropPersonificationObjects2= [];
gdjs.GameCode.GDDropPersonificationObjects3= [];
gdjs.GameCode.GDDropPersonificationObjects4= [];
gdjs.GameCode.GDSimileTexObjects1= [];
gdjs.GameCode.GDSimileTexObjects2= [];
gdjs.GameCode.GDSimileTexObjects3= [];
gdjs.GameCode.GDSimileTexObjects4= [];
gdjs.GameCode.GDHyperboleTexObjects1= [];
gdjs.GameCode.GDHyperboleTexObjects2= [];
gdjs.GameCode.GDHyperboleTexObjects3= [];
gdjs.GameCode.GDHyperboleTexObjects4= [];
gdjs.GameCode.GDMetaphorTexObjects1= [];
gdjs.GameCode.GDMetaphorTexObjects2= [];
gdjs.GameCode.GDMetaphorTexObjects3= [];
gdjs.GameCode.GDMetaphorTexObjects4= [];
gdjs.GameCode.GDPersonificationTexObjects1= [];
gdjs.GameCode.GDPersonificationTexObjects2= [];
gdjs.GameCode.GDPersonificationTexObjects3= [];
gdjs.GameCode.GDPersonificationTexObjects4= [];
gdjs.GameCode.GDAnswerBallsSCreenObjects1= [];
gdjs.GameCode.GDAnswerBallsSCreenObjects2= [];
gdjs.GameCode.GDAnswerBallsSCreenObjects3= [];
gdjs.GameCode.GDAnswerBallsSCreenObjects4= [];
gdjs.GameCode.GDAnswerBallsObjects1= [];
gdjs.GameCode.GDAnswerBallsObjects2= [];
gdjs.GameCode.GDAnswerBallsObjects3= [];
gdjs.GameCode.GDAnswerBallsObjects4= [];
gdjs.GameCode.GDComboObjects1= [];
gdjs.GameCode.GDComboObjects2= [];
gdjs.GameCode.GDComboObjects3= [];
gdjs.GameCode.GDComboObjects4= [];
gdjs.GameCode.GDTotalAnswerObjects1= [];
gdjs.GameCode.GDTotalAnswerObjects2= [];
gdjs.GameCode.GDTotalAnswerObjects3= [];
gdjs.GameCode.GDTotalAnswerObjects4= [];
gdjs.GameCode.GDTotalPCTObjects1= [];
gdjs.GameCode.GDTotalPCTObjects2= [];
gdjs.GameCode.GDTotalPCTObjects3= [];
gdjs.GameCode.GDTotalPCTObjects4= [];
gdjs.GameCode.GDMENUObjects1= [];
gdjs.GameCode.GDMENUObjects2= [];
gdjs.GameCode.GDMENUObjects3= [];
gdjs.GameCode.GDMENUObjects4= [];
gdjs.GameCode.GDHIStreakTxtObjects1= [];
gdjs.GameCode.GDHIStreakTxtObjects2= [];
gdjs.GameCode.GDHIStreakTxtObjects3= [];
gdjs.GameCode.GDHIStreakTxtObjects4= [];
gdjs.GameCode.GDHIStreakObjects1= [];
gdjs.GameCode.GDHIStreakObjects2= [];
gdjs.GameCode.GDHIStreakObjects3= [];
gdjs.GameCode.GDHIStreakObjects4= [];
gdjs.GameCode.GDTotalPCTTxtObjects1= [];
gdjs.GameCode.GDTotalPCTTxtObjects2= [];
gdjs.GameCode.GDTotalPCTTxtObjects3= [];
gdjs.GameCode.GDTotalPCTTxtObjects4= [];
gdjs.GameCode.GDTotalWrongObjects1= [];
gdjs.GameCode.GDTotalWrongObjects2= [];
gdjs.GameCode.GDTotalWrongObjects3= [];
gdjs.GameCode.GDTotalWrongObjects4= [];
gdjs.GameCode.GDTotalWrongTxtObjects1= [];
gdjs.GameCode.GDTotalWrongTxtObjects2= [];
gdjs.GameCode.GDTotalWrongTxtObjects3= [];
gdjs.GameCode.GDTotalWrongTxtObjects4= [];
gdjs.GameCode.GDTotalAnswerTxtObjects1= [];
gdjs.GameCode.GDTotalAnswerTxtObjects2= [];
gdjs.GameCode.GDTotalAnswerTxtObjects3= [];
gdjs.GameCode.GDTotalAnswerTxtObjects4= [];
gdjs.GameCode.GDPercentTxtObjects1= [];
gdjs.GameCode.GDPercentTxtObjects2= [];
gdjs.GameCode.GDPercentTxtObjects3= [];
gdjs.GameCode.GDPercentTxtObjects4= [];
gdjs.GameCode.GDComboTxtObjects1= [];
gdjs.GameCode.GDComboTxtObjects2= [];
gdjs.GameCode.GDComboTxtObjects3= [];
gdjs.GameCode.GDComboTxtObjects4= [];
gdjs.GameCode.GDTimerObjects1= [];
gdjs.GameCode.GDTimerObjects2= [];
gdjs.GameCode.GDTimerObjects3= [];
gdjs.GameCode.GDTimerObjects4= [];
gdjs.GameCode.GDSentenObjects1= [];
gdjs.GameCode.GDSentenObjects2= [];
gdjs.GameCode.GDSentenObjects3= [];
gdjs.GameCode.GDSentenObjects4= [];
gdjs.GameCode.GDCorrectObjects1= [];
gdjs.GameCode.GDCorrectObjects2= [];
gdjs.GameCode.GDCorrectObjects3= [];
gdjs.GameCode.GDCorrectObjects4= [];
gdjs.GameCode.GDCamPointObjects1= [];
gdjs.GameCode.GDCamPointObjects2= [];
gdjs.GameCode.GDCamPointObjects3= [];
gdjs.GameCode.GDCamPointObjects4= [];
gdjs.GameCode.GDRetryObjects1= [];
gdjs.GameCode.GDRetryObjects2= [];
gdjs.GameCode.GDRetryObjects3= [];
gdjs.GameCode.GDRetryObjects4= [];
gdjs.GameCode.GDFireObjects1= [];
gdjs.GameCode.GDFireObjects2= [];
gdjs.GameCode.GDFireObjects3= [];
gdjs.GameCode.GDFireObjects4= [];
gdjs.GameCode.GDFGreatObjects1= [];
gdjs.GameCode.GDFGreatObjects2= [];
gdjs.GameCode.GDFGreatObjects3= [];
gdjs.GameCode.GDFGreatObjects4= [];
gdjs.GameCode.GDKillingItObjects1= [];
gdjs.GameCode.GDKillingItObjects2= [];
gdjs.GameCode.GDKillingItObjects3= [];
gdjs.GameCode.GDKillingItObjects4= [];
gdjs.GameCode.GDWhatObjects1= [];
gdjs.GameCode.GDWhatObjects2= [];
gdjs.GameCode.GDWhatObjects3= [];
gdjs.GameCode.GDWhatObjects4= [];

gdjs.GameCode.conditionTrue_0 = {val:false};
gdjs.GameCode.condition0IsTrue_0 = {val:false};
gdjs.GameCode.condition1IsTrue_0 = {val:false};
gdjs.GameCode.condition2IsTrue_0 = {val:false};
gdjs.GameCode.condition3IsTrue_0 = {val:false};
gdjs.GameCode.condition4IsTrue_0 = {val:false};
gdjs.GameCode.conditionTrue_1 = {val:false};
gdjs.GameCode.condition0IsTrue_1 = {val:false};
gdjs.GameCode.condition1IsTrue_1 = {val:false};
gdjs.GameCode.condition2IsTrue_1 = {val:false};
gdjs.GameCode.condition3IsTrue_1 = {val:false};
gdjs.GameCode.condition4IsTrue_1 = {val:false};


gdjs.GameCode.eventsList0 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 1;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.GameCode.GDTimerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(60);
}{for(var i = 0, len = gdjs.GameCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTimerObjects2[i].hide(false);
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "7bb8457e462829641e35c95909e2e40ff5488fcc973268de863f05112c4e16dc_Llama in Pajama.aac", 1, true, 70, 1);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 2;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.GameCode.GDTimerObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(15);
}{for(var i = 0, len = gdjs.GameCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTimerObjects2[i].hide(false);
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "0b5a6149ed67036ef9ec6bd0c163c840938380638495125a689e702ce2d6550a_Video Game Blockbuster.aac", 1, true, 100, 1);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.GameCode.GDTimerObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(999999999);
}{for(var i = 0, len = gdjs.GameCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDTimerObjects1[i].hide();
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "bccfc899ea0e1284c803de7861171cb8f8869f87ceb6cd3858d5e1ae31d40faf_Take the Ride.aac", 1, true, 55, 1);
}}

}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectSimileObjects1Objects = Hashtable.newFrom({"SelectSimile": gdjs.GameCode.GDSelectSimileObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectSimileObjects1Objects = Hashtable.newFrom({"SelectSimile": gdjs.GameCode.GDSelectSimileObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectHyperboleObjects1Objects = Hashtable.newFrom({"SelectHyperbole": gdjs.GameCode.GDSelectHyperboleObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectHyperboleObjects1Objects = Hashtable.newFrom({"SelectHyperbole": gdjs.GameCode.GDSelectHyperboleObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectMetaphorObjects1Objects = Hashtable.newFrom({"SelectMetaphor": gdjs.GameCode.GDSelectMetaphorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectMetaphorObjects1Objects = Hashtable.newFrom({"SelectMetaphor": gdjs.GameCode.GDSelectMetaphorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectPersonificationObjects1Objects = Hashtable.newFrom({"SelectPersonification": gdjs.GameCode.GDSelectPersonificationObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectPersonificationObjects1Objects = Hashtable.newFrom({"SelectPersonification": gdjs.GameCode.GDSelectPersonificationObjects1});
gdjs.GameCode.eventsList2 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 20));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "r");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 20));
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Combo"), gdjs.GameCode.GDComboObjects2);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.GameCode.GDTimerObjects2);
gdjs.copyArray(runtimeScene.getObjects("TotalAnswer"), gdjs.GameCode.GDTotalAnswerObjects2);
gdjs.copyArray(runtimeScene.getObjects("TotalPCT"), gdjs.GameCode.GDTotalPCTObjects2);
gdjs.copyArray(runtimeScene.getObjects("TotalWrong"), gdjs.GameCode.GDTotalWrongObjects2);
{for(var i = 0, len = gdjs.GameCode.GDComboObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDComboObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}{for(var i = 0, len = gdjs.GameCode.GDTotalAnswerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTotalAnswerObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}{for(var i = 0, len = gdjs.GameCode.GDTotalWrongObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTotalWrongObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}{for(var i = 0, len = gdjs.GameCode.GDTotalPCTObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTotalPCTObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) * 100);
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(Math.ceil(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))));
}{for(var i = 0, len = gdjs.GameCode.GDTimerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTimerObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))));
}
}{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) / 2);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 20;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("The brown grass was begging for water.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Personification");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 19;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("The cactus saluted any visitor brave enough to travel the scorched land.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Personification");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 18;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("Jan ate the hotdog despite the arguments it posed to her digestive system.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Personification");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 17;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("Money is the only friend that I can count on.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Personification");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 16;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("The clock stares at me very strongly as I wait for the bell.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Personification");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 15;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("This job is the cancer of my dreams and aspirations.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Metaphor");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 14;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("My heart swelled with a sea of tears.\n");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Metaphor");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 13;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("Scars are the roadmap to the soul.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Metaphor");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 12;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("Laughter is the music of the soul.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Metaphor");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 11;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("John’s answer to the problem was just a Band-Aid, not a solution.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Metaphor");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("We were playing this board game for days!");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Hyperbole");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 9;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("The cat slept for days!");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Hyperbole");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 8;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("The teacher gave out piles of homework.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Hyperbole");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 7;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("I have told you a million times to wash the dishes.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Hyperbole");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 6;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("You snore like a freight train.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Hyperbole");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 5;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("Grandpa lounged on the raft in the middle of the pool like an old battleship.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Simile");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 4;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("The handshake felt like warm laundry.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Simile");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("You are soft as the nesting dove.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Simile");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 2;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects2);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects2[i].setString("He spit out his teeth like stones.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Simile");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Senten"), gdjs.GameCode.GDSentenObjects1);
{for(var i = 0, len = gdjs.GameCode.GDSentenObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSentenObjects1[i].setString("There are strange birds like blots against a sky.");
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("Simile");
}}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSimileObjects2Objects = Hashtable.newFrom({"Simile": gdjs.GameCode.GDSimileObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects3});
gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10)) > 7;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Boo!.wav", false, 150, 1);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0);
}}

}


};gdjs.GameCode.eventsList4 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Simile";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropSimile"), gdjs.GameCode.GDDropSimileObjects3);
gdjs.GameCode.GDAnswerBallsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects, (( gdjs.GameCode.GDDropSimileObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropSimileObjects3[0].getPointX("Origin")), (( gdjs.GameCode.GDDropSimileObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropSimileObjects3[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Simile");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "error_006.ogg", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 20));
}{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.GameCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDHyperboleObjects2Objects = Hashtable.newFrom({"Hyperbole": gdjs.GameCode.GDHyperboleObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects3});
gdjs.GameCode.eventsList5 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10)) > 7;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Boo!.wav", false, 150, 1);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0);
}}

}


};gdjs.GameCode.eventsList6 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Hyperbole";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropHyperbole"), gdjs.GameCode.GDDropHyperboleObjects3);
gdjs.GameCode.GDAnswerBallsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects, (( gdjs.GameCode.GDDropHyperboleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropHyperboleObjects3[0].getPointX("Origin")), (( gdjs.GameCode.GDDropHyperboleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropHyperboleObjects3[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Hyperbole");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "error_006.ogg", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 20));
}{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.GameCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMetaphorObjects2Objects = Hashtable.newFrom({"Metaphor": gdjs.GameCode.GDMetaphorObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects3});
gdjs.GameCode.eventsList7 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10)) > 7;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Boo!.wav", false, 150, 1);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0);
}}

}


};gdjs.GameCode.eventsList8 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Metaphor";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropMetaphor"), gdjs.GameCode.GDDropMetaphorObjects3);
gdjs.GameCode.GDAnswerBallsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects, (( gdjs.GameCode.GDDropMetaphorObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropMetaphorObjects3[0].getPointX("Origin")), (( gdjs.GameCode.GDDropMetaphorObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropMetaphorObjects3[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Metaphor");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "error_006.ogg", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 20));
}{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.GameCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPersonificationObjects1Objects = Hashtable.newFrom({"Personification": gdjs.GameCode.GDPersonificationObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects2Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects2});
gdjs.GameCode.eventsList9 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(10)) > 7;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Boo!.wav", false, 150, 1);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0);
}}

}


};gdjs.GameCode.eventsList10 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Personification";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropPersonification"), gdjs.GameCode.GDDropPersonificationObjects2);
gdjs.GameCode.GDAnswerBallsObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects2Objects, (( gdjs.GameCode.GDDropPersonificationObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDDropPersonificationObjects2[0].getPointX("Origin")), (( gdjs.GameCode.GDDropPersonificationObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDDropPersonificationObjects2[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Personification");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "error_006.ogg", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 20));
}{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.GameCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Simile"), gdjs.GameCode.GDSimileObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSimileObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hyperbole"), gdjs.GameCode.GDHyperboleObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDHyperboleObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Metaphor"), gdjs.GameCode.GDMetaphorObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMetaphorObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Personification"), gdjs.GameCode.GDPersonificationObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPersonificationObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSimileObjects1Objects = Hashtable.newFrom({"Simile": gdjs.GameCode.GDSimileObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDHyperboleObjects1Objects = Hashtable.newFrom({"Hyperbole": gdjs.GameCode.GDHyperboleObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMetaphorObjects1Objects = Hashtable.newFrom({"Metaphor": gdjs.GameCode.GDMetaphorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPersonificationObjects1Objects = Hashtable.newFrom({"Personification": gdjs.GameCode.GDPersonificationObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCorrectObjects1Objects = Hashtable.newFrom({"Correct": gdjs.GameCode.GDCorrectObjects1});
gdjs.GameCode.eventsList12 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 2;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).add(2);
}}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects3});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects3});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects3});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects2Objects = Hashtable.newFrom({"AnswerBalls": gdjs.GameCode.GDAnswerBallsObjects2});
gdjs.GameCode.eventsList13 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Simile";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropSimile"), gdjs.GameCode.GDDropSimileObjects3);
gdjs.GameCode.GDAnswerBallsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects, (( gdjs.GameCode.GDDropSimileObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropSimileObjects3[0].getPointX("Origin")), (( gdjs.GameCode.GDDropSimileObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropSimileObjects3[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Hyperbole";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropHyperbole"), gdjs.GameCode.GDDropHyperboleObjects3);
gdjs.GameCode.GDAnswerBallsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects, (( gdjs.GameCode.GDDropHyperboleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropHyperboleObjects3[0].getPointX("Origin")), (( gdjs.GameCode.GDDropHyperboleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropHyperboleObjects3[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Metaphor";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropMetaphor"), gdjs.GameCode.GDDropMetaphorObjects3);
gdjs.GameCode.GDAnswerBallsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects3Objects, (( gdjs.GameCode.GDDropMetaphorObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropMetaphorObjects3[0].getPointX("Origin")), (( gdjs.GameCode.GDDropMetaphorObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDDropMetaphorObjects3[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)) == "Personification";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DropPersonification"), gdjs.GameCode.GDDropPersonificationObjects2);
gdjs.GameCode.GDAnswerBallsObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects2Objects, (( gdjs.GameCode.GDDropPersonificationObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDDropPersonificationObjects2[0].getPointX("Origin")), (( gdjs.GameCode.GDDropPersonificationObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDDropPersonificationObjects2[0].getPointY("Origin")), "");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


};gdjs.GameCode.eventsList14 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "r");
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CamPoint"), gdjs.GameCode.GDCamPointObjects2);
{for(var i = 0, len = gdjs.GameCode.GDCamPointObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDCamPointObjects2[i].setPosition(681,1755);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.7, "", 0);
}{gdjs.evtTools.storage.readNumberFromJSONFile("HiStreak", "HiStreak", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "z");
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "h");
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8217300);
}
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(7);
}}

}


};gdjs.GameCode.eventsList15 = function(runtimeScene) {

};gdjs.GameCode.eventsList16 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 2);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.setMusicOnChannelPitch(runtimeScene, 1, 2);
}}

}


};gdjs.GameCode.eventsList17 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) < 6;
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) > 0;
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition2IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13517564);
}
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Tick.wav", false, 100, 1);
}{gdjs.evtTools.tween.tweenCameraZoom(runtimeScene, "Danger", 1.1, "", 1000, "easeTo");
}{gdjs.evtTools.tween.tweenCameraRotation(runtimeScene, "Danger", 1, "", 500, "easeTo");
}
{ //Subevents
gdjs.GameCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
gdjs.GameCode.condition3IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) < 10;
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) > 5;
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
gdjs.GameCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 2;
}if ( gdjs.GameCode.condition2IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition3IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13518796);
}
}}
}
}
if (gdjs.GameCode.condition3IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Tick.wav", false, 100, 1);
}{gdjs.evtTools.tween.tweenCameraZoom(runtimeScene, "Danger", 1.1, "", 1000, "easeTo");
}{gdjs.evtTools.tween.tweenCameraRotation(runtimeScene, "Danger", 1, "", 500, "easeTo");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 2);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) > 5;
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition2IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13520780);
}
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {
{gdjs.evtTools.tween.tweenCameraZoom(runtimeScene, "UnDanger", 1, "", 500, "easeTo");
}{gdjs.evtTools.tween.tweenCameraRotation(runtimeScene, "UnDanger", 0, "", 500, "easeTo");
}{gdjs.evtTools.sound.setMusicOnChannelPitch(runtimeScene, 1, 1);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) == 2;
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) > 9;
}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition2IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13522060);
}
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {
{gdjs.evtTools.tween.tweenCameraZoom(runtimeScene, "UnDanger", 1, "", 500, "easeTo");
}{gdjs.evtTools.tween.tweenCameraRotation(runtimeScene, "UnDanger", 0, "", 500, "easeTo");
}}

}


};gdjs.GameCode.eventsList18 = function(runtimeScene) {

};gdjs.GameCode.eventsList19 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) == 1;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.GameCode.GDFireObjects2);
{for(var i = 0, len = gdjs.GameCode.GDFireObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects2[i].setBBText("[shadow=Yellow]ON FIRE![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) == 2;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.GameCode.GDFireObjects2);
{for(var i = 0, len = gdjs.GameCode.GDFireObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects2[i].setBBText("[shadow=Red]ON FIRE![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.GameCode.GDFireObjects1);
{for(var i = 0, len = gdjs.GameCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects1[i].setBBText("[shadow=Orange]ON FIRE![/shadow]");
}
}}

}


};gdjs.GameCode.eventsList20 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 1;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=Green]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 2;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=Blue]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 3;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=Yellow]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 4;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=Purple]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 5;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=Red]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 6;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=LightBlue]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 7;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=Pink]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 8;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects2);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects2[i].setBBText("[shadow=Gray]WHAT?!?!?![/shadow]");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) == 9;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects1);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects1[i].setBBText("[shadow=Orange]WHAT?!?!?![/shadow]");
}
}}

}


};gdjs.GameCode.eventsList21 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13));
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("HIStreak"), gdjs.GameCode.GDHIStreakObjects1);
{for(var i = 0, len = gdjs.GameCode.GDHIStreakObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDHIStreakObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


};gdjs.GameCode.eventsList22 = function(runtimeScene) {

{


gdjs.GameCode.eventsList21(runtimeScene);
}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.GameCode.GDCursorObjects1});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDRetryObjects1Objects = Hashtable.newFrom({"Retry": gdjs.GameCode.GDRetryObjects1});
gdjs.GameCode.eventsList23 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CamPoint"), gdjs.GameCode.GDCamPointObjects1);
{for(var i = 0, len = gdjs.GameCode.GDCamPointObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDCamPointObjects1[i].setPosition(707,514);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "", 0);
}
{ //Subevents
gdjs.GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.eventsList1(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectSimile"), gdjs.GameCode.GDSelectSimileObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectSimileObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13452524);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDSelectSimileObjects1 */
gdjs.copyArray(runtimeScene.getObjects("SimileTex"), gdjs.GameCode.GDSimileTexObjects1);
{for(var i = 0, len = gdjs.GameCode.GDSelectSimileObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectSimileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDSimileTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSimileTexObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "drop_003.ogg", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectSimile"), gdjs.GameCode.GDSelectSimileObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectSimileObjects1Objects, true, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13452836);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDSelectSimileObjects1 */
gdjs.copyArray(runtimeScene.getObjects("SimileTex"), gdjs.GameCode.GDSimileTexObjects1);
{for(var i = 0, len = gdjs.GameCode.GDSelectSimileObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectSimileObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDSimileTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSimileTexObjects1[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectHyperbole"), gdjs.GameCode.GDSelectHyperboleObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectHyperboleObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13454804);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HyperboleTex"), gdjs.GameCode.GDHyperboleTexObjects1);
/* Reuse gdjs.GameCode.GDSelectHyperboleObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDSelectHyperboleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectHyperboleObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDHyperboleTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDHyperboleTexObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "drop_003.ogg", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectHyperbole"), gdjs.GameCode.GDSelectHyperboleObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectHyperboleObjects1Objects, true, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13456348);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HyperboleTex"), gdjs.GameCode.GDHyperboleTexObjects1);
/* Reuse gdjs.GameCode.GDSelectHyperboleObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDSelectHyperboleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectHyperboleObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDHyperboleTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDHyperboleTexObjects1[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectMetaphor"), gdjs.GameCode.GDSelectMetaphorObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectMetaphorObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13457180);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MetaphorTex"), gdjs.GameCode.GDMetaphorTexObjects1);
/* Reuse gdjs.GameCode.GDSelectMetaphorObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDSelectMetaphorObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectMetaphorObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDMetaphorTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMetaphorTexObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "drop_003.ogg", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectMetaphor"), gdjs.GameCode.GDSelectMetaphorObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectMetaphorObjects1Objects, true, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13458724);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MetaphorTex"), gdjs.GameCode.GDMetaphorTexObjects1);
/* Reuse gdjs.GameCode.GDSelectMetaphorObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDSelectMetaphorObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectMetaphorObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDMetaphorTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMetaphorTexObjects1[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectPersonification"), gdjs.GameCode.GDSelectPersonificationObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectPersonificationObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13459420);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PersonificationTex"), gdjs.GameCode.GDPersonificationTexObjects1);
/* Reuse gdjs.GameCode.GDSelectPersonificationObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDSelectPersonificationObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectPersonificationObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDPersonificationTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPersonificationTexObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "drop_003.ogg", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SelectPersonification"), gdjs.GameCode.GDSelectPersonificationObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSelectPersonificationObjects1Objects, true, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13460892);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PersonificationTex"), gdjs.GameCode.GDPersonificationTexObjects1);
/* Reuse gdjs.GameCode.GDSelectPersonificationObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDSelectPersonificationObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSelectPersonificationObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDPersonificationTexObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPersonificationTexObjects1[i].hide();
}
}}

}


{


{
}

}


{


gdjs.GameCode.eventsList2(runtimeScene);
}


{


gdjs.GameCode.eventsList11(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("AnswerBalls"), gdjs.GameCode.GDAnswerBallsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Simile"), gdjs.GameCode.GDSimileObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDSimileObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDAnswerBallsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDAnswerBallsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAnswerBallsObjects1[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AnswerBalls"), gdjs.GameCode.GDAnswerBallsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hyperbole"), gdjs.GameCode.GDHyperboleObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDHyperboleObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDAnswerBallsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDAnswerBallsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAnswerBallsObjects1[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AnswerBalls"), gdjs.GameCode.GDAnswerBallsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Metaphor"), gdjs.GameCode.GDMetaphorObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMetaphorObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDAnswerBallsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDAnswerBallsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAnswerBallsObjects1[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AnswerBalls"), gdjs.GameCode.GDAnswerBallsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Personification"), gdjs.GameCode.GDPersonificationObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDAnswerBallsObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPersonificationObjects1Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDAnswerBallsObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDAnswerBallsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAnswerBallsObjects1[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AnswerBalls"), gdjs.GameCode.GDAnswerBallsObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDAnswerBallsObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDAnswerBallsObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDAnswerBallsObjects1[k] = gdjs.GameCode.GDAnswerBallsObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDAnswerBallsObjects1.length = k;}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13506948);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDAnswerBallsObjects1 */
gdjs.GameCode.GDCorrectObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCorrectObjects1Objects, (( gdjs.GameCode.GDAnswerBallsObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDAnswerBallsObjects1[0].getPointX("Center")), (( gdjs.GameCode.GDAnswerBallsObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDAnswerBallsObjects1[0].getPointY("Center")) + 50, "");
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.GameCode.GDAnswerBallsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAnswerBallsObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 20));
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "confirmation_002.ogg", false, 100, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) / 5);
}
{ //Subevents
gdjs.GameCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.eventsList14(runtimeScene);
}


{


gdjs.GameCode.eventsList15(runtimeScene);
}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "timer") >= 1;
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) > 0;
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}{runtimeScene.getGame().getVariables().getFromIndex(8).sub(1);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(gdjs.randomInRange(1, 3));
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(gdjs.randomInRange(1, 9));
}
{ //Subevents
gdjs.GameCode.eventsList17(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) == 0;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CamPoint"), gdjs.GameCode.GDCamPointObjects1);
{for(var i = 0, len = gdjs.GameCode.GDCamPointObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDCamPointObjects1[i].setPosition(681,1755);
}
}{gdjs.evtTools.sound.setMusicOnChannelPitch(runtimeScene, 1, 1);
}{gdjs.evtTools.tween.tweenCameraZoom(runtimeScene, "UnDanger", 0.7, "", 500, "easeTo");
}{gdjs.evtTools.tween.tweenCameraRotation(runtimeScene, "UnDanger", 0, "", 500, "easeTo");
}{gdjs.evtTools.storage.writeNumberInJSONFile("HiStreak", "HiStreak", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13)));
}{gdjs.evtTools.storage.readNumberFromJSONFile("HiStreak", "HiStreak", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}}

}


{


gdjs.GameCode.eventsList18(runtimeScene);
}


{


{

{ //Subevents
gdjs.GameCode.eventsList19(runtimeScene);} //End of subevents
}

}


{


{

{ //Subevents
gdjs.GameCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 6;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("FGreat"), gdjs.GameCode.GDFGreatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.GameCode.GDFireObjects1);
gdjs.copyArray(runtimeScene.getObjects("KillingIt"), gdjs.GameCode.GDKillingItObjects1);
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects1);
{for(var i = 0, len = gdjs.GameCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDFGreatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFGreatObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDKillingItObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDKillingItObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDWhatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDFGreatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFGreatObjects1[i].getBehavior("ShakeObject_PositionAngle").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects1[i].getBehavior("ShakeObject_PositionAngle").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDKillingItObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDKillingItObjects1[i].getBehavior("ShakeObject_PositionAngle").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDWhatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects1[i].getBehavior("ShakeObject_PositionAngle").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > 6;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("FGreat"), gdjs.GameCode.GDFGreatObjects1);
{for(var i = 0, len = gdjs.GameCode.GDFGreatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFGreatObjects1[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.GameCode.GDFGreatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFGreatObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(10, 2, 2, 2, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > 12;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("FGreat"), gdjs.GameCode.GDFGreatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.GameCode.GDFireObjects1);
{for(var i = 0, len = gdjs.GameCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects1[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.GameCode.GDFGreatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFGreatObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(10, 5, 5, 5, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > 19;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("FGreat"), gdjs.GameCode.GDFGreatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.GameCode.GDFireObjects1);
gdjs.copyArray(runtimeScene.getObjects("KillingIt"), gdjs.GameCode.GDKillingItObjects1);
{for(var i = 0, len = gdjs.GameCode.GDKillingItObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDKillingItObjects1[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.GameCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDFGreatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFGreatObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDKillingItObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDKillingItObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(10, 9, 9, 3, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > 29;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("FGreat"), gdjs.GameCode.GDFGreatObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.GameCode.GDFireObjects1);
gdjs.copyArray(runtimeScene.getObjects("KillingIt"), gdjs.GameCode.GDKillingItObjects1);
gdjs.copyArray(runtimeScene.getObjects("What"), gdjs.GameCode.GDWhatObjects1);
{for(var i = 0, len = gdjs.GameCode.GDWhatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects1[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.GameCode.GDKillingItObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDKillingItObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFireObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDFGreatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFGreatObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDWhatObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDWhatObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(10, 20, 20, 3, 0, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


gdjs.GameCode.eventsList22(runtimeScene);
}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
{for(var i = 0, len = gdjs.GameCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDCursorObjects1[i].setColor("0;0;0");
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left"));
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
{for(var i = 0, len = gdjs.GameCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDCursorObjects1[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.GameCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Retry"), gdjs.GameCode.GDRetryObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCursorObjects1Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDRetryObjects1Objects, false, runtimeScene, false);
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
gdjs.GameCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDCursorObjects1.length = 0;
gdjs.GameCode.GDCursorObjects2.length = 0;
gdjs.GameCode.GDCursorObjects3.length = 0;
gdjs.GameCode.GDCursorObjects4.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.GameCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.GameCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.GameCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.GameCode.GDNewTiledSprite2Objects3.length = 0;
gdjs.GameCode.GDNewTiledSprite2Objects4.length = 0;
gdjs.GameCode.GDSimileObjects1.length = 0;
gdjs.GameCode.GDSimileObjects2.length = 0;
gdjs.GameCode.GDSimileObjects3.length = 0;
gdjs.GameCode.GDSimileObjects4.length = 0;
gdjs.GameCode.GDHyperboleObjects1.length = 0;
gdjs.GameCode.GDHyperboleObjects2.length = 0;
gdjs.GameCode.GDHyperboleObjects3.length = 0;
gdjs.GameCode.GDHyperboleObjects4.length = 0;
gdjs.GameCode.GDMetaphorObjects1.length = 0;
gdjs.GameCode.GDMetaphorObjects2.length = 0;
gdjs.GameCode.GDMetaphorObjects3.length = 0;
gdjs.GameCode.GDMetaphorObjects4.length = 0;
gdjs.GameCode.GDPersonificationObjects1.length = 0;
gdjs.GameCode.GDPersonificationObjects2.length = 0;
gdjs.GameCode.GDPersonificationObjects3.length = 0;
gdjs.GameCode.GDPersonificationObjects4.length = 0;
gdjs.GameCode.GDSelectSimileObjects1.length = 0;
gdjs.GameCode.GDSelectSimileObjects2.length = 0;
gdjs.GameCode.GDSelectSimileObjects3.length = 0;
gdjs.GameCode.GDSelectSimileObjects4.length = 0;
gdjs.GameCode.GDSelectHyperboleObjects1.length = 0;
gdjs.GameCode.GDSelectHyperboleObjects2.length = 0;
gdjs.GameCode.GDSelectHyperboleObjects3.length = 0;
gdjs.GameCode.GDSelectHyperboleObjects4.length = 0;
gdjs.GameCode.GDSelectMetaphorObjects1.length = 0;
gdjs.GameCode.GDSelectMetaphorObjects2.length = 0;
gdjs.GameCode.GDSelectMetaphorObjects3.length = 0;
gdjs.GameCode.GDSelectMetaphorObjects4.length = 0;
gdjs.GameCode.GDSelectPersonificationObjects1.length = 0;
gdjs.GameCode.GDSelectPersonificationObjects2.length = 0;
gdjs.GameCode.GDSelectPersonificationObjects3.length = 0;
gdjs.GameCode.GDSelectPersonificationObjects4.length = 0;
gdjs.GameCode.GDDropSimileObjects1.length = 0;
gdjs.GameCode.GDDropSimileObjects2.length = 0;
gdjs.GameCode.GDDropSimileObjects3.length = 0;
gdjs.GameCode.GDDropSimileObjects4.length = 0;
gdjs.GameCode.GDDropHyperboleObjects1.length = 0;
gdjs.GameCode.GDDropHyperboleObjects2.length = 0;
gdjs.GameCode.GDDropHyperboleObjects3.length = 0;
gdjs.GameCode.GDDropHyperboleObjects4.length = 0;
gdjs.GameCode.GDDropMetaphorObjects1.length = 0;
gdjs.GameCode.GDDropMetaphorObjects2.length = 0;
gdjs.GameCode.GDDropMetaphorObjects3.length = 0;
gdjs.GameCode.GDDropMetaphorObjects4.length = 0;
gdjs.GameCode.GDDropPersonificationObjects1.length = 0;
gdjs.GameCode.GDDropPersonificationObjects2.length = 0;
gdjs.GameCode.GDDropPersonificationObjects3.length = 0;
gdjs.GameCode.GDDropPersonificationObjects4.length = 0;
gdjs.GameCode.GDSimileTexObjects1.length = 0;
gdjs.GameCode.GDSimileTexObjects2.length = 0;
gdjs.GameCode.GDSimileTexObjects3.length = 0;
gdjs.GameCode.GDSimileTexObjects4.length = 0;
gdjs.GameCode.GDHyperboleTexObjects1.length = 0;
gdjs.GameCode.GDHyperboleTexObjects2.length = 0;
gdjs.GameCode.GDHyperboleTexObjects3.length = 0;
gdjs.GameCode.GDHyperboleTexObjects4.length = 0;
gdjs.GameCode.GDMetaphorTexObjects1.length = 0;
gdjs.GameCode.GDMetaphorTexObjects2.length = 0;
gdjs.GameCode.GDMetaphorTexObjects3.length = 0;
gdjs.GameCode.GDMetaphorTexObjects4.length = 0;
gdjs.GameCode.GDPersonificationTexObjects1.length = 0;
gdjs.GameCode.GDPersonificationTexObjects2.length = 0;
gdjs.GameCode.GDPersonificationTexObjects3.length = 0;
gdjs.GameCode.GDPersonificationTexObjects4.length = 0;
gdjs.GameCode.GDAnswerBallsSCreenObjects1.length = 0;
gdjs.GameCode.GDAnswerBallsSCreenObjects2.length = 0;
gdjs.GameCode.GDAnswerBallsSCreenObjects3.length = 0;
gdjs.GameCode.GDAnswerBallsSCreenObjects4.length = 0;
gdjs.GameCode.GDAnswerBallsObjects1.length = 0;
gdjs.GameCode.GDAnswerBallsObjects2.length = 0;
gdjs.GameCode.GDAnswerBallsObjects3.length = 0;
gdjs.GameCode.GDAnswerBallsObjects4.length = 0;
gdjs.GameCode.GDComboObjects1.length = 0;
gdjs.GameCode.GDComboObjects2.length = 0;
gdjs.GameCode.GDComboObjects3.length = 0;
gdjs.GameCode.GDComboObjects4.length = 0;
gdjs.GameCode.GDTotalAnswerObjects1.length = 0;
gdjs.GameCode.GDTotalAnswerObjects2.length = 0;
gdjs.GameCode.GDTotalAnswerObjects3.length = 0;
gdjs.GameCode.GDTotalAnswerObjects4.length = 0;
gdjs.GameCode.GDTotalPCTObjects1.length = 0;
gdjs.GameCode.GDTotalPCTObjects2.length = 0;
gdjs.GameCode.GDTotalPCTObjects3.length = 0;
gdjs.GameCode.GDTotalPCTObjects4.length = 0;
gdjs.GameCode.GDMENUObjects1.length = 0;
gdjs.GameCode.GDMENUObjects2.length = 0;
gdjs.GameCode.GDMENUObjects3.length = 0;
gdjs.GameCode.GDMENUObjects4.length = 0;
gdjs.GameCode.GDHIStreakTxtObjects1.length = 0;
gdjs.GameCode.GDHIStreakTxtObjects2.length = 0;
gdjs.GameCode.GDHIStreakTxtObjects3.length = 0;
gdjs.GameCode.GDHIStreakTxtObjects4.length = 0;
gdjs.GameCode.GDHIStreakObjects1.length = 0;
gdjs.GameCode.GDHIStreakObjects2.length = 0;
gdjs.GameCode.GDHIStreakObjects3.length = 0;
gdjs.GameCode.GDHIStreakObjects4.length = 0;
gdjs.GameCode.GDTotalPCTTxtObjects1.length = 0;
gdjs.GameCode.GDTotalPCTTxtObjects2.length = 0;
gdjs.GameCode.GDTotalPCTTxtObjects3.length = 0;
gdjs.GameCode.GDTotalPCTTxtObjects4.length = 0;
gdjs.GameCode.GDTotalWrongObjects1.length = 0;
gdjs.GameCode.GDTotalWrongObjects2.length = 0;
gdjs.GameCode.GDTotalWrongObjects3.length = 0;
gdjs.GameCode.GDTotalWrongObjects4.length = 0;
gdjs.GameCode.GDTotalWrongTxtObjects1.length = 0;
gdjs.GameCode.GDTotalWrongTxtObjects2.length = 0;
gdjs.GameCode.GDTotalWrongTxtObjects3.length = 0;
gdjs.GameCode.GDTotalWrongTxtObjects4.length = 0;
gdjs.GameCode.GDTotalAnswerTxtObjects1.length = 0;
gdjs.GameCode.GDTotalAnswerTxtObjects2.length = 0;
gdjs.GameCode.GDTotalAnswerTxtObjects3.length = 0;
gdjs.GameCode.GDTotalAnswerTxtObjects4.length = 0;
gdjs.GameCode.GDPercentTxtObjects1.length = 0;
gdjs.GameCode.GDPercentTxtObjects2.length = 0;
gdjs.GameCode.GDPercentTxtObjects3.length = 0;
gdjs.GameCode.GDPercentTxtObjects4.length = 0;
gdjs.GameCode.GDComboTxtObjects1.length = 0;
gdjs.GameCode.GDComboTxtObjects2.length = 0;
gdjs.GameCode.GDComboTxtObjects3.length = 0;
gdjs.GameCode.GDComboTxtObjects4.length = 0;
gdjs.GameCode.GDTimerObjects1.length = 0;
gdjs.GameCode.GDTimerObjects2.length = 0;
gdjs.GameCode.GDTimerObjects3.length = 0;
gdjs.GameCode.GDTimerObjects4.length = 0;
gdjs.GameCode.GDSentenObjects1.length = 0;
gdjs.GameCode.GDSentenObjects2.length = 0;
gdjs.GameCode.GDSentenObjects3.length = 0;
gdjs.GameCode.GDSentenObjects4.length = 0;
gdjs.GameCode.GDCorrectObjects1.length = 0;
gdjs.GameCode.GDCorrectObjects2.length = 0;
gdjs.GameCode.GDCorrectObjects3.length = 0;
gdjs.GameCode.GDCorrectObjects4.length = 0;
gdjs.GameCode.GDCamPointObjects1.length = 0;
gdjs.GameCode.GDCamPointObjects2.length = 0;
gdjs.GameCode.GDCamPointObjects3.length = 0;
gdjs.GameCode.GDCamPointObjects4.length = 0;
gdjs.GameCode.GDRetryObjects1.length = 0;
gdjs.GameCode.GDRetryObjects2.length = 0;
gdjs.GameCode.GDRetryObjects3.length = 0;
gdjs.GameCode.GDRetryObjects4.length = 0;
gdjs.GameCode.GDFireObjects1.length = 0;
gdjs.GameCode.GDFireObjects2.length = 0;
gdjs.GameCode.GDFireObjects3.length = 0;
gdjs.GameCode.GDFireObjects4.length = 0;
gdjs.GameCode.GDFGreatObjects1.length = 0;
gdjs.GameCode.GDFGreatObjects2.length = 0;
gdjs.GameCode.GDFGreatObjects3.length = 0;
gdjs.GameCode.GDFGreatObjects4.length = 0;
gdjs.GameCode.GDKillingItObjects1.length = 0;
gdjs.GameCode.GDKillingItObjects2.length = 0;
gdjs.GameCode.GDKillingItObjects3.length = 0;
gdjs.GameCode.GDKillingItObjects4.length = 0;
gdjs.GameCode.GDWhatObjects1.length = 0;
gdjs.GameCode.GDWhatObjects2.length = 0;
gdjs.GameCode.GDWhatObjects3.length = 0;
gdjs.GameCode.GDWhatObjects4.length = 0;

gdjs.GameCode.eventsList23(runtimeScene);

return;

}

gdjs['GameCode'] = gdjs.GameCode;
